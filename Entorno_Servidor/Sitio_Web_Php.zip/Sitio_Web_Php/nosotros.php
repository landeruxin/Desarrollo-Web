<!DOCTYPE html>
<html lang="es">
<head>
    <?php include("./includes/inc_config.php"); ?>
    
    <title>Sobre nosotros</title>
</head>
<body>
   <?php   include("./includes/inc_cabecera.php"); ?>


   <div id="cajon">    

   
        <?php include("includes/inc_formulario_contacto.php"); ?>


    </div>

  

  
    
    
   <?php  include("./includes/inc_pie.php"); ?>

   <?php  include("./includes/inc_javascript.php"); ?>

   
</body>
</html>
