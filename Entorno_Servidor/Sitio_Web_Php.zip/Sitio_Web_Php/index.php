<!DOCTYPE html>
<html lang="es">
<head>
    <?php include("./includes/inc_config.php"); ?>
    
    <title>Página principal</title>
</head>
<body>
   <?php   include("./includes/inc_cabecera.php"); ?>
   <div id="imagenes">
   <ul>
                <li>
                <img src="fotos/fondo1.jpg" alt="foto_inicio1" id="portada1">
                </li>
                <li>
                <img src="fotos/fondo2.jpg" alt="foto_inicio2" id="portada2">
               </li>
                <li>
                <img src="fotos/fondo3.jpg" alt="foto_inicio3" id="portada3">
                </li>
            </ul>
            </div>
   
    
    
   <?php  include("./includes/inc_pie.php"); ?>

   <?php  include("./includes/inc_javascript.php"); ?>

   
</body>
</html>
