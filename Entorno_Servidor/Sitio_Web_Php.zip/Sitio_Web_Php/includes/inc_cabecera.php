<!-- Menu Navegacion -->

<nav class="nav">
    <div class="container">
        <div class="logo">
            <a href="index.php">NORFER</a>
        </div>
        <div class="main_list" id="mainListDiv">
            <ul>
                <li><a href="index.php">Incio</a></li>
                <li><a href="nosotros.php">Contacto php</a></li>
                <li><a href="servicios.php">Servicios</a></li>
                <li><a href="contacto.php">Contactanos</a></li>
            </ul>
        </div>
    </div>
</nav>