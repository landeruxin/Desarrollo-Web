<!-- importaciones javascript -->
<script type="text/javascript" src="javascript/jquery-3.5.1.min.js"> </script>
    <script type="text/javascript" src="javascript/javascript.js"> </script>